1. Windows Vista or later, you can ignore this.
    If not already install .Net framework 2.0 or higher on your computer, please download and install it before using Blumind. Recommend you to the Microsoft Web site (http://download.microsoft.com) download it. Reference http://www.blumind.org
   
2. You can go to Blumind website http://www.blumind.org/download find the latest version, may be there are some new features that you want, or fixed some bugs.

3. Finally, I hope you can enjoy this software. If you have any questions, comments or suggestions, please visit my web site or email to blumindorg@gmail.com


----------------------------------------------------------------------
Command Arguments:
----------------------------------------------------------------------
-p 			: force run as portable mode
-regbmd		: associate .bmd file type
-unregbmd	: disassociate .bmd file type
